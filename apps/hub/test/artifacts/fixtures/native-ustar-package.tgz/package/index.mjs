export const fixture = 'DYTEST native USTAR';
